'Fraction Arithmetic - DS1706 - Decision Tree'

OVERVIEW
Project:          Apprentice Learner Architecture Simulated Students Datasets
PI:               Christopher MacLellan
Curriculum:       
Dates:            Dec 31, 1969 - Dec 31, 1969
Domain/LearnLab:  Math/Other
Tutor:            
Description:      Most specific where, decision tree when, incremental how
Has Study Data:   No
Status:           
School(s):        
Additional Notes: 06/12/2017: Dataset uploaded by Christopher MacLellan.

STATISTICS
Number of Students:               79
Number of Unique Steps:          302
Total Number of Steps:        18,924
Total Number of Transactions: 23,703
Total Student Hours:               5.91
Knowledge Component Model(s): Field (22 knowledge components)
                              Literal Field (8 knowledge components)
                              Rule Name (12 knowledge components)
                              Single-KC (1 knowledge component)
                              Unique-step (252 knowledge components)

CITATION/ACKNOWLEDGMENT

If you publish research based on this dataset, please include the following 
acknowledgement: 

Acknowledgment:

   We used the 'Fraction Arithmetic - DS1706 - Decision Tree' dataset accessed

or

   We used the 'Fraction Arithmetic - DS1706 - Decision Tree' dataset accessed

To cite the DataShop web application and repository, please include the 
following reference in your publication:

   Koedinger, K.R., Baker, R.S.J.d., Cunningham, K., Skogsholm, A., Leber, B.,
   Stamper, J. (2010) A Data Repository for the EDM community: The PSLC
   DataShop. In Romero, C., Ventura, S., Pechenizkiy, M., Baker, R.S.J.d.
   (Eds.) Handbook of Educational Data Mining. Boca Raton, FL: CRC Press.

You might also cite the DataShop URL in the text of your paper: 

   For exploratory analysis, I used the PSLC DataShop, available at
   http://pslcdatashop.web.cmu.edu (Koedinger et al., 2010).

Additional information on citing DataShop is available here: 
http://www.pslcdatashop.web.cmu.edu/help?page=citing